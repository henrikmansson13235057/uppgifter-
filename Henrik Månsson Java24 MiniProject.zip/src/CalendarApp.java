import javax.swing.*;
import java.awt.*;
import java.util.Calendar;

public class CalendarApp extends JFrame {
    private final CalendarPanel calendarPanel; // kalenderpanel där datum visas
    private final JLabel monthLabel; // En etikett som visar aktuell månad och år
    private int year, month; // En variabel som håller reda på månad och år

    public CalendarApp() { // En konstruktor för CaledarApp som skapar huvudfönstret och dess innehåll
        JFrame frame = new JFrame("Calender"); // titel för själva programmet
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Stänger programmet
        frame.setSize(600, 600); // Sätter storlek på fönstret

        // Hämtar de aktuella året och månaden
        year = Calendar.getInstance().get(Calendar.YEAR);
        month = Calendar.getInstance().get(Calendar.MONTH);
        // skapar topppanelen för navigering (knappar, månadsetiket)
        JPanel topPanel = new JPanel();
        monthLabel = new JLabel();// Etiket för att visa aktuell månad och år.
        JButton prevButton = new JButton("<");// en knapp som man kan gå till förgående månad
        JButton nextButton = new JButton(">"); // en knapp som man kan klicka framåt.
        // Lägger till funktionalitet för navigeringsknapparna
        prevButton.addActionListener(e -> navigateMonth(-1)); // går till förgående månad
        nextButton.addActionListener(e -> navigateMonth(+1)); // går till nästa månad
        // lägger till knappar och etiket till topppanelen
        topPanel.add(prevButton);
        topPanel.add(nextButton);
        topPanel.add(monthLabel);

        frame.add(topPanel, BorderLayout.NORTH); // lägger till topppanelen längst upp
        // skapar caledarpanel och lägger till den i mitten av fönstret
        calendarPanel = new CalendarPanel(year, month);
        frame.add(calendarPanel, BorderLayout.CENTER);

        updateMonthLabel(); // uppdaterar månads etikett till aktuell månad

        frame.setVisible(true);// visar fönstret

    }
// metod för att navigera mellan månader
    private void navigateMonth(int offset) {

        month += offset; // ändra månaden med det givna offset
        if (month < 0) {
            month = 11; // går till december från förgående år
            year--;
        } else if (month > 11) {
            month = 0; // går till januari nästa år
            year++;


        }
        calendarPanel.updateCalendar(year, month);// uppdaterar kalendern med det nya året och månaden
        updateMonthLabel(); // uppdaterar månaden
    }
    // En metod för att uppdatera månadsetikett
    private void updateMonthLabel() {
        Calendar cal = Calendar.getInstance(); // skapar en kalederinsats
        cal.set(year, month, 1); // sätter den till första dagen i aktuell månad och år
        monthLabel.setText(String.format("%tB %d", cal, year)); // formaterar månadsetiketten för att visa te.x (januari 2023)
    }
}
