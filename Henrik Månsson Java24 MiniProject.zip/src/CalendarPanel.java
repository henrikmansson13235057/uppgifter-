import javax.swing.*;
import java.util.Calendar;
import java.awt.*;

public class CalendarPanel extends JPanel {
    private final DayPanel[] dayPanel; // en array som representerar alla dagar i kalendern

    public CalendarPanel(int year, int month) { // en konstruktor som skapar kalenderpanelen
        setLayout(new GridLayout(7, 7)); // sätter en layout till veckodagar och dagar
        addDayHeaders(); // lägger till rubrikera för veckodagarna
        dayPanel = new DayPanel[42];// skaprar en array för att hantera upp till 42 dagar (maximalt 6 veckor) det är inklusive tumma rutor som inte tillhör den aktuella månaden

        for (int i = 0; i < dayPanel.length; i++) {
            dayPanel[i] = new DayPanel(); // skapar en daypanel för varje dag
            add(dayPanel[i]); // lägger till den i layouten

        }
        updateCalendar(year, month); // uppdaterar kaledern år och månad

    }

    private void addDayHeaders() { // en metod som lägger till rukbrikerna för veckodagarna
        String[] headers = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"}; // array för veckodagsrubriken
        for (String header : headers) {
            add(new JLabel(header, SwingConstants.CENTER)); // lägger till rubriken som en centrerad Jlabel
        }
    }


            public void updateCalendar(int year, int month) { // en metod för att uppdatera kalendern med aktuell månad och år
                // skapar en kalederinsats och stäler in den på första dagen i månaden
                Calendar calendar = Calendar.getInstance();
                calendar.set(year ,month, 1);

                int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);// Hämtar antalet dagar i en månad
                int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK) - 2; // Hämtar vilken veckodag den första dagen i en månad är
                if (firstDayOfWeek < 0) firstDayOfWeek += 7; // Justerar så att det börjar på måndag
                // Hämtar dagens datum om det är samma månad och år
                Calendar today = Calendar.getInstance();
                int todayDay = (today.get(Calendar.YEAR) == year && today.get(Calendar.MONTH) == month)
                        ? today.get(Calendar.DAY_OF_MONTH) : -1;

                for (DayPanel panel : dayPanel) { // ränsar alla daypaneler
                    panel.clearDay();
                }
                // Fyller i dagarna för månaden i rätt position i kaledern
                for (int day = 1, i = firstDayOfWeek; day <= daysInMonth; day++, i++) {
                    dayPanel[i].setDay(day); // Sätter i dag nummret i panelen
                    if (day == todayDay) {
                        dayPanel[i].highlightToday(); // använde Chatgpt här för jag satt fast med att highlighta dagen
                    }
                }
            }
}
