import javax.swing.*;
import java.awt.*;

public class EventEditior extends JFrame {
    private final JTextArea eventTextArea; // textfält dör att skriva och redigera text

    public EventEditior(int day, String currentEvent, DayPanel dayPanel) {
        setTitle("Lägg Till Händelser - " + day); // ställer in föstertitlen med dagens datum (Lägg till händelser 20
        setSize(400,200); // storleken på fönstret
        setLocationRelativeTo(null); // öppnas i mitten av skärmen

        eventTextArea = new JTextArea(currentEvent,5, 20); // skapar ett textområde med eventuell befitlig händelsetext
        JButton saveButton = new JButton("Save"); // skapar en knapp där man kan spara

        saveButton.addActionListener(e -> { // skapar en listener när knappen trycks och sparar det du skrev in
            dayPanel.setEventText(eventTextArea.getText());// sätter in händelsetexten för den aktuella dagen
            dispose();// stänger ner redigerings fönstret
        });
        JPanel panel = new JPanel(new BorderLayout()); // skapar en panel med borderlayout för att arragera komponentera
        panel.add(new JScrollPane(eventTextArea), BorderLayout.CENTER); // lägger till textområdet med rullningslist i mitten av panelen
        panel.add(saveButton, BorderLayout.SOUTH); // lägger till sparknappen längst ner
        add(panel); // lägger in hela panelen i fönstret
        setVisible(true);

    }
}
