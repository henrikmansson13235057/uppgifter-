import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DayPanel extends JPanel {
    private int day; // Används för vilken dag det är
    private String eventText;// Används där man kan skriva in sina händelser till vilken dag
    private final JLabel dayLabel; // label för att visa dagens datum

    public DayPanel() {
        setBorder(BorderFactory.createLineBorder(Color.GRAY)); // sätter en kantlinje runt panelen
        setLayout(new BorderLayout()); // sätter layout för att centrera texten i panelen
        dayLabel = new JLabel("",SwingConstants.CENTER); // skapar och lägger till för att visa dagens nummer
        add(dayLabel, BorderLayout.CENTER);

        addMouseListener(new MouseAdapter() { // lägger till MouseListener för att öppna eventredigeraren när man klickar
            @Override
            public void mouseClicked(MouseEvent e) {// öppnar eventredigeararen om dagen är större än 0
                if (day > 0){
                    new EventEditior(day, eventText, DayPanel.this).setVisible(true);
                }
            }
        });
    }
public void setDay(int day) { // sätter dagens nummer och visar det i labeln
        this.day = day;
        dayLabel.setText(String.valueOf(day)); // konverterar numret till text
}
public void setEventText(String eventText) { // sätter text till händelse och ändrar bakgrundsfärg
        this.eventText = eventText;
        setBackground(eventText.isEmpty() ? Color.WHITE : Color.LIGHT_GRAY); // ljusgrå om det finns en händelse annars vit
}
public void clearDay(){ // ränsar dages data (När dagen inte är aktuell)
        day = 0; // återställer dagens nummer
        dayLabel.setText(""); // Tömmer label
        eventText = ""; // Tömmer hädelsetexten
        setBackground(Color.WHITE); // återställer bakgrundsfärgen till vit
}
    public void highlightToday() { // Markerar dagens datum med färgen cyan
        setBackground(Color.CYAN);
    }
}

